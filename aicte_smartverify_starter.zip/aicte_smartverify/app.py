import streamlit as st
import sqlite3, json, hashlib, re
from datetime import datetime, date
from pathlib import Path
import fitz

APP_DIR = Path(__file__).parent
DB_PATH = APP_DIR / "smartverify.db"
UPLOAD_DIR = APP_DIR / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)

st.set_page_config(page_title="AICTE SmartVerify", page_icon="🛡️", layout="wide")

def db():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS applications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            institution TEXT NOT NULL,
            institution_code TEXT,
            category TEXT NOT NULL,
            submitted_by TEXT,
            created_at TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Submitted'
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            application_id INTEGER NOT NULL,
            filename TEXT NOT NULL,
            doc_type TEXT NOT NULL,
            extracted_text TEXT,
            sha256 TEXT,
            uploaded_at TEXT NOT NULL,
            FOREIGN KEY(application_id) REFERENCES applications(id)
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS findings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            application_id INTEGER NOT NULL,
            document_id INTEGER,
            rule_code TEXT NOT NULL,
            status TEXT NOT NULL,
            explanation TEXT NOT NULL,
            evidence TEXT,
            created_at TEXT NOT NULL
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            application_id INTEGER,
            action TEXT NOT NULL,
            details TEXT,
            timestamp TEXT NOT NULL
        )""")
init_db()

def audit(app_id, action, details=""):
    with db() as con:
        con.execute("INSERT INTO audit_logs(application_id,action,details,timestamp) VALUES(?,?,?,?)",
                    (app_id, action, details, datetime.now().isoformat(timespec="seconds")))

def extract_pdf_text(data):
    try:
        doc = fitz.open(stream=data, filetype="pdf")
        return "\n".join(page.get_text() for page in doc).strip()
    except Exception:
        return ""

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def classify_doc(filename):
    s = filename.lower()
    if "noc" in s or "no_objection" in s: return "NOC / Permission"
    if "affidavit" in s or "undertaking" in s: return "Affidavit / Undertaking"
    if "accredit" in s or "naac" in s or "nba" in s: return "Accreditation / Certification"
    if "faculty" in s or "staff" in s: return "Faculty Record"
    if "infra" in s or "building" in s or "floor" in s: return "Infrastructure Evidence"
    if "approval" in s or "eoa" in s: return "Previous Approval"
    if "certificate" in s or "cert" in s: return "Certificate"
    return "Other / Unclassified"

def parse_date(s):
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y", "%d.%m.%Y"):
        try: return datetime.strptime(s.strip(), fmt).date()
        except ValueError: pass
    return None

def run_validation(app_id):
    with db() as con:
        app = con.execute("SELECT * FROM applications WHERE id=?", (app_id,)).fetchone()
        docs = con.execute("SELECT * FROM documents WHERE application_id=?", (app_id,)).fetchall()
        con.execute("DELETE FROM findings WHERE application_id=?", (app_id,))
        now = datetime.now().isoformat(timespec="seconds")
        findings = []
        present_types = {d["doc_type"] for d in docs}
        # Demo checklist: explain to users that actual requirements are configurable.
        required = ["Affidavit / Undertaking", "NOC / Permission", "Previous Approval"]
        for req in required:
            if req not in present_types:
                findings.append((app_id, None, "DOC-REQUIRED", "Missing",
                                 f"Expected document type not found: {req}.",
                                 "Checklist used: prototype demo checklist. Confirm requirements for the actual application category."))
        if not docs:
            findings.append((app_id, None, "DOC-NONE", "Missing",
                             "No documents have been uploaded for this application.", "Upload the required supporting files."))
        all_text = []
        for d in docs:
            txt = d["extracted_text"] or ""
            all_text.append((d, txt))
            if not txt.strip():
                findings.append((app_id, d["id"], "OCR-EMPTY", "Manual review",
                                 f"No selectable text was extracted from {d['filename']}.",
                                 "This may be a scanned PDF or image. Use OCR or manually review the document."))
            for label, patterns in [
                ("institution code", [r"(?:institution|college)\s*(?:code|id)\s*[:\-]\s*([A-Za-z0-9\-]+)"]),
                ("certificate number", [r"(?:certificate|reference)\s*(?:no|number|#)\s*[:\-]\s*([A-Za-z0-9\/\-]+)"])
            ]:
                for pat in patterns:
                    if re.search(pat, txt, re.I):
                        break
            # Dates are advisory only; do not assume every date is an expiry date.
            for match in re.finditer(r"(?:valid\s*(?:until|upto|up to)|expiry\s*date|expires\s*on)\s*[:\-]?\s*(\d{4}-\d{2}-\d{2}|\d{2}[/-]\d{2}[/-]\d{4})", txt, re.I):
                dt = parse_date(match.group(1))
                if dt and dt < date.today():
                    findings.append((app_id, d["id"], "CERT-EXPIRED", "Expired",
                                     f"Possible expired validity date in {d['filename']}: {dt.isoformat()}.",
                                     f"Matched text: {match.group(0)}. Confirm that this is the governing expiry date."))
        # Compare repeated institution codes/names in extracted text (basic heuristic).
        codes = {}
        for d, txt in all_text:
            m = re.search(r"(?:institution|college)\s*(?:code|id)\s*[:\-]\s*([A-Za-z0-9\-]+)", txt, re.I)
            if m:
                codes.setdefault(m.group(1).upper(), []).append(d["filename"])
        if len(codes) > 1:
            details = "; ".join(f"{code}: {', '.join(names)}" for code, names in codes.items())
            findings.append((app_id, None, "CROSS-DOC-CODE", "Mismatch",
                             "Different institution codes were found across uploaded documents.",
                             details))
        # Exact duplicate upload detection by hash.
        hashes = {}
        for d in docs:
            if d["sha256"]:
                hashes.setdefault(d["sha256"], []).append(d["filename"])
        for h, names in hashes.items():
            if len(names) > 1:
                findings.append((app_id, None, "DUPLICATE-FILE", "Review",
                                 "Identical file content was uploaded more than once.",
                                 ", ".join(names)))
        if not findings:
            findings.append((app_id, None, "CHECKS-COMPLETE", "Passed",
                             "No issues were identified by the configured prototype checks.",
                             "This is not an approval decision or proof that every document is authentic."))
        con.executemany("""INSERT INTO findings(application_id,document_id,rule_code,status,explanation,evidence,created_at)
                           VALUES(?,?,?,?,?,?,?)""",
                        [(a,b,c,d,e,f,now) for a,b,c,d,e,f in findings])
        con.execute("UPDATE applications SET status=? WHERE id=?",
                    ("Review required" if any(x[3] in ("Missing","Expired","Mismatch","Manual review","Review") for x in findings) else "Checks complete", app_id))
    audit(app_id, "Validation run", f"{len(findings)} finding(s) generated")
    return len(findings)

def status_badge(status):
    colors = {"Passed":"🟢", "Missing":"🔴", "Expired":"🔴", "Mismatch":"🟠",
              "Manual review":"🟠", "Review":"🟠", "Verified (demo)":"🟢",
              "Mismatch (demo)":"🟠", "Pending":"🟡", "Unavailable":"⚪"}
    return f"{colors.get(status, '🔵')} {status}"

st.title("🛡️ AICTE SmartVerify")
st.caption("AI-powered application validation and document authentication — demonstration prototype")
st.warning("Prototype notice: this application uses a demo checklist and simulated issuer verification. It is not connected to AICTE or government databases. Findings are advisory and must be reviewed by authorized officials.")

pages = ["Overview", "Create application", "Upload documents", "Validate & review", "Audit history"]
page = st.sidebar.radio("Navigation", pages)
with db() as con:
    applications = con.execute("SELECT * FROM applications ORDER BY id DESC").fetchall()

if page == "Overview":
    st.subheader("Validation overview")
    with db() as con:
        total = con.execute("SELECT COUNT(*) n FROM applications").fetchone()["n"]
        docs_n = con.execute("SELECT COUNT(*) n FROM documents").fetchone()["n"]
        findings_n = con.execute("SELECT COUNT(*) n FROM findings WHERE status NOT IN ('Passed')").fetchone()["n"]
        review_n = con.execute("SELECT COUNT(*) n FROM applications WHERE status='Review required'").fetchone()["n"]
    a,b,c,d = st.columns(4)
    a.metric("Applications", total)
    b.metric("Documents uploaded", docs_n)
    c.metric("Findings to review", findings_n)
    d.metric("Cases needing review", review_n)
    st.subheader("Recent applications")
    if applications:
        st.dataframe([dict(x) for x in applications], use_container_width=True, hide_index=True)
    else:
        st.info("No applications yet. Open **Create application** to add a demo institution.")
    st.subheader("Suggested demo sequence")
    st.markdown("1. Create an application.  2. Upload documents with meaningful filenames.  3. Run validation.  4. Review findings and audit history.")

elif page == "Create application":
    st.subheader("Create an application")
    with st.form("create_app"):
        institution = st.text_input("Institution name", placeholder="Example: Sunrise Institute of Technology")
        code = st.text_input("Institution code / ID", placeholder="Example: DEMO-102")
        category = st.selectbox("Application category", ["Extension of Approval (EoA)", "New programme / course", "Change in intake", "Institutional details update", "Other approval-related change"])
        submitted_by = st.text_input("Submitted by", placeholder="Demo user")
        submitted = st.form_submit_button("Create application", type="primary")
    if submitted:
        if not institution.strip():
            st.error("Enter an institution name.")
        else:
            with db() as con:
                cur = con.execute("INSERT INTO applications(institution,institution_code,category,submitted_by,created_at,status) VALUES(?,?,?,?,?,?)",
                    (institution.strip(), code.strip(), category, submitted_by.strip(), datetime.now().isoformat(timespec="seconds"), "Submitted"))
                app_id = cur.lastrowid
            audit(app_id, "Application created", institution.strip())
            st.success(f"Application #{app_id} created. Go to Upload documents next.")

elif page == "Upload documents":
    st.subheader("Upload supporting documents")
    if not applications:
        st.info("Create an application first.")
    else:
        labels = {f"#{x['id']} — {x['institution']} ({x['category']})": x["id"] for x in applications}
        chosen = st.selectbox("Select application", list(labels.keys()))
        app_id = labels[chosen]
        files_in = st.file_uploader("Choose PDF or image files", type=["pdf", "png", "jpg", "jpeg"], accept_multiple_files=True)
        if files_in:
            st.caption("Digital PDFs are text-extracted. Image files and scanned PDFs may need OCR; this prototype flags empty text for manual review.")
        if st.button("Save uploaded documents", type="primary", disabled=not files_in):
            saved = 0
            for f in files_in:
                data = f.getvalue()
                digest = sha256(data)
                safe_name = re.sub(r"[^A-Za-z0-9._-]", "_", f.name)
                stored = UPLOAD_DIR / f"{app_id}_{digest[:10]}_{safe_name}"
                stored.write_bytes(data)
                text = extract_pdf_text(data) if f.name.lower().endswith(".pdf") else ""
                doc_type = classify_doc(f.name)
                with db() as con:
                    con.execute("INSERT INTO documents(application_id,filename,doc_type,extracted_text,sha256,uploaded_at) VALUES(?,?,?,?,?,?)",
                                (app_id, f.name, doc_type, text, digest, datetime.now().isoformat(timespec="seconds")))
                audit(app_id, "Document uploaded", f"{f.name} ({doc_type})")
                saved += 1
            st.success(f"Saved {saved} document(s). Go to Validate & review.")
        with db() as con:
            docs = con.execute("SELECT * FROM documents WHERE application_id=? ORDER BY id DESC", (app_id,)).fetchall()
        if docs:
            st.markdown("**Uploaded files**")
            st.dataframe([{"Filename":d["filename"], "Detected type":d["doc_type"], "Text extracted": "Yes" if (d["extracted_text"] or "").strip() else "No / OCR needed", "SHA-256":(d["sha256"] or "")[:16]+"…"} for d in docs], use_container_width=True, hide_index=True)

elif page == "Validate & review":
    st.subheader("Run validation and review results")
    if not applications:
        st.info("Create an application first.")
    else:
        labels = {f"#{x['id']} — {x['institution']}": x["id"] for x in applications}
        chosen = st.selectbox("Select application to validate", list(labels.keys()))
        app_id = labels[chosen]
        with db() as con:
            app = con.execute("SELECT * FROM applications WHERE id=?", (app_id,)).fetchone()
            docs = con.execute("SELECT * FROM documents WHERE application_id=? ORDER BY id", (app_id,)).fetchall()
        st.write(f"**Category:** {app['category']}  |  **Current status:** {app['status']}")
        if st.button("Run validation checks", type="primary"):
            n = run_validation(app_id)
            st.success(f"Validation finished. {n} finding(s) generated.")
        with db() as con:
            findings = con.execute("SELECT * FROM findings WHERE application_id=? ORDER BY id DESC", (app_id,)).fetchall()
        if findings:
            for f in findings:
                with st.expander(f"{status_badge(f['status'])} — {f['rule_code']}: {f['explanation']}", expanded=f["status"] != "Passed"):
                    st.write("**Explanation:**", f["explanation"])
                    st.write("**Evidence / next step:**", f["evidence"] or "No additional evidence recorded.")
                    st.caption(f"Finding created: {f['created_at']}")
            report = {
                "application": dict(app),
                "documents": [{"filename": d["filename"], "type": d["doc_type"]} for d in docs],
                "findings": [dict(f) for f in findings],
                "generated_at": datetime.now().isoformat(timespec="seconds"),
                "notice": "Advisory prototype output; not an AICTE decision."
            }
            st.download_button("Download validation report (JSON)", json.dumps(report, indent=2), file_name=f"smartverify_application_{app_id}_report.json", mime="application/json")
        st.divider()
        st.subheader("Demo issuer verification")
        st.caption("This is simulated only; it does not contact any issuing authority.")
        with st.form("issuer_demo"):
            cert_no = st.text_input("Certificate / reference number", placeholder="Example: DEMO-123")
            source = st.selectbox("Demo issuer source", ["Demo Certificate Registry", "Demo Accreditation Registry", "Demo Permission Registry"])
            submitted = st.form_submit_button("Run simulated check")
        if submitted:
            result = "Verified (demo)" if cert_no.strip().upper().startswith("DEMO-") else "Mismatch (demo)"
            detail = "A matching sample record was found in the simulated registry." if result == "Verified (demo)" else "No matching sample record in the simulated registry. This is not evidence of forgery."
            st.info(f"{status_badge(result)} — {detail}")
            audit(app_id, "Simulated issuer verification", f"Source={source}; reference={cert_no}; result={result}")

elif page == "Audit history":
    st.subheader("Audit history")
    with db() as con:
        logs = con.execute("""SELECT a.id application_id, a.institution, l.action, l.details, l.timestamp
                              FROM audit_logs l LEFT JOIN applications a ON a.id=l.application_id
                              ORDER BY l.id DESC LIMIT 500""").fetchall()
    if logs:
        st.dataframe([dict(x) for x in logs], use_container_width=True, hide_index=True)
        st.caption("Audit entries are stored in the local prototype database. A production system would need stronger tamper-evident logging and access controls.")
    else:
        st.info("No audit events yet.")

st.sidebar.divider()
st.sidebar.caption("SmartVerify prototype • Demo data only")
